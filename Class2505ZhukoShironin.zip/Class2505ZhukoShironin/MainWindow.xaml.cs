﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Class2505ZhukoShironin;

namespace Class2505ZhukoShironin
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void BtnAddRad_Click(object sender, RoutedEventArgs e)
        {
            Circle c;
            Reactangle r;
            Triangle t;
            double p, s;
            c = new Circle (Convert.ToDouble(AddRadiusCircle.Text));
            p = c.Perimeter();
            s = c.Square();
            ResultCircle.Text = $"Периметр окружности = {Math.Round(p, 2, MidpointRounding.AwayFromZero)}, Площадь = {Math.Round(s, 2, MidpointRounding.AwayFromZero)}";
            r = new Reactangle(Convert.ToDouble(AddRectangleSide.Text), Convert.ToDouble(AddRectangleSide2.Text));
            p = r.Perimeter();
            s = r.Square();
            ResultRectangle.Text = $"Периметр прямоугольника = {Math.Round(p, 2, MidpointRounding.AwayFromZero)}, Площадь = {Math.Round(s, 2, MidpointRounding.AwayFromZero)}";
            t = new Triangle(Convert.ToDouble(AddTriangelCircle.Text),
                Convert.ToDouble(AddTriangelCircle2.Text),
                Convert.ToDouble(AddTriangelCircle3.Text));
            p = t.Perimeter();
            s = t.Square();
            ResultTriangel.Text = $"Периметр треугольника = {Math.Round(p, 2, MidpointRounding.AwayFromZero)}, Площадь = {Math.Round(s, 2, MidpointRounding.AwayFromZero)}";
        }
    }
}
